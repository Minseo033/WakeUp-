package com.kms.wakeup.ui.main

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Switch
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.kms.wakeup.R

class AlarmAdapter(
    private val items: List<AlarmItem>
) : RecyclerView.Adapter<AlarmAdapter.AlarmViewHolder>() {

    class AlarmViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val timeText: TextView = view.findViewById(R.id.alarm_time_text)
        val labelText: TextView = view.findViewById(R.id.alarm_label_text)
        val alarmSwitch: Switch = view.findViewById(R.id.alarm_switch)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlarmViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_alarm, parent, false)
        return AlarmViewHolder(view)
    }

    override fun onBindViewHolder(holder: AlarmViewHolder, position: Int) {
        val item = items[position]
        holder.timeText.text = item.timeText
        holder.labelText.text = item.labelText
        holder.alarmSwitch.isChecked = item.isEnabled
    }

    override fun getItemCount(): Int = items.size
}