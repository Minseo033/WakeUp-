package com.kms.wakeup.ui.main

data class AlarmItem(
    val timeText: String,
    val labelText: String,
    val isEnabled: Boolean
)